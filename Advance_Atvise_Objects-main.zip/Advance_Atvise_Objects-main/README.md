# Advance_Atvise_Objects
An extensive library of advance SCADA objects for the automation industry
